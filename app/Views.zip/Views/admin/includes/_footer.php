<footer class="main-footer no-print">
    <span><b>Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo base_url(); ?>">Find My Law Firm</a>.</b> All rights reserved.</span>
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> <?php echo get_general_settings()->version ?>
    </div>
</footer>
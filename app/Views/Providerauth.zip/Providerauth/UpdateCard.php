<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
    <div class="plan bg-gray pt-2 pb-4 pb-xl-5">
        <?php echo $this->include('Common/_messages') ?>
		<div class="titleSec text-center mb-3 mb-xl-4">
			<h3 class="title-xl text-black mb-0 mb-sm-5"><?php echo $title; ?></h3>
		</div>
		<div class="container">
			<div class='row'>
				<div class="col-sm-4 offset-md-2">
					<div class="carddetail">
						<h3 class="title-sm dblue mb-0">Saved Card:</h3>
						<?php if(isset($cards->card->brand)){ ?>
							<p>Your credit card on file is a <strong><?php echo $cards->card->brand;?></strong> ending in <strong><?php echo $cards->card->last4;?></strong>
							</p>
						<?php }	?>	
					</div>
					<hr>
					<div class="carddetail">
						<h3 class="title-sm dblue mb-0">Subscription:</h3>
						<?php
						foreach ($subscriptions->data as $subscription) {
						    if ($subscription->status == 'active') {
						?>
                            <p><?php echo $subscription->metadata->title . " ($" . moneyFormat($subscription->plan->amount / 100) . "/mo)";?>
                            <br><strong class="dblue">Last Payment:</strong> <?php echo date("m/d/Y", $subscription->current_period_start);?>
                            <br><strong class="dblue">Next Payment:</strong> <?php echo date("m/d/Y", $subscription->current_period_end);?>
                            <br>
                            </p>
                        <?php }
						}
						?>

					</div>
				</div>
				<div class='col-sm-6'>
					<p class="mb-1">Please enter your credit card information below</p>
					<form id="card-form" action='<?php echo base_url(); ?>/providerauth/update-card-post' method='post'>	
							<div class="credit-card-input no-js form-group" id="skeuocard">
							<label for="cc_type">Card Type</label>
							<select name="cc_type" class="form-control">
							  <option value="">...</option>
							  <option value="visa">Visa</option>
							  <option value="discover">Discover</option>
							  <option value="mastercard">MasterCard</option>
							  <option value="maestro">Maestro</option>
							  <option value="jcb">JCB</option>
							  <option value="unionpay">China UnionPay</option>
							  <option value="amex">American Express</option>
							  <option value="dinersclubintl">Diners Club</option>
							</select>
							<label for="cc_number">Card Number</label>
							<input type="text" class="form-control" name="cc_number" id="cc_number" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" size="19">
							<label for="cc_exp_month">Expiration Month</label>
							<input type="text" class="form-control" name="cc_exp_month" id="cc_exp_month" placeholder="00">
							<label for="cc_exp_year">Expiration Year</label>
							<input type="text" class="form-control" name="cc_exp_year" id="cc_exp_year" placeholder="00">
							<label for="cc_name">Cardholder's Name</label>
							<input type="text" class="form-control" name="cc_name" id="cc_name" placeholder="John Doe">
							<label for="cc_cvc">Card Validation Code</label>
							<input type="text" class="form-control" name="cc_cvc" id="cc_cvc" placeholder="123" maxlength="3" size="3">
						  </div>
						  <br>						  
						  <input type="hidden" name="customerId" value="<?php echo $customerId; ?>" />
						  <input type='submit' value='Update' class='btn'>
						  <a href="<?php echo base_url().'/providerauth/billing/';?>" class="cancel btn">Back</a>
					</form>
				</div>
			</div>
		</div>
		</div>
<div class="loader"></div>
<script>
$(function(){
  $('#card-form').submit(function() {
    $('.loader').show(); 
    return true;
  });
});
</script>		
<?= $this->endSection() ?>
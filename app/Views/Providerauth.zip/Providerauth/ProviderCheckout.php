<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
    <div class="plan bg-gray pt-2 pb-4 pb-xl-5">
        <?php echo $this->include('Common/_messages') ?>
		<div class="titleSec text-center mb-3 mb-xl-4">
			<h3 class="title-xl dblue mb-0"><?php echo $title; ?></h3>
		</div>
		<div class="container">
			<h6 class='text-lg'><b><i class='fa fa-trophy'></i> Purchase our <?php echo $plan_detail[0]->name; ?> Plan for $<?php echo str_replace('.00', '', $plan_detail[0]->price); ?>/mo.</b></h6>
			<div class='text-sm'>Upgrading means <b>increased exposure</b>, additional photos, features, and more flexibility.</div><hr>
			<div class='row'>
				<div class='col-12 col-sm-6'>
					<p>Please enter your credit card information below</p>
					<form id="payment-form" action='<?php echo base_url(); ?>/providerauth/checkout-post' method='post' class="mb-4">
						<input type="hidden" name="plan_id" value="<?php echo $plan_detail[0]->id; ?>" />
						<input type="hidden" name="type" value="<?php echo $type; ?>" />
							<!--<div class="credit-card-input no-js form-group" id="skeuocard">
							<label for="cc_type">Card Type</label>
							<select name="cc_type" class="form-control">
							  <option value="">...</option>
							  <option value="visa">Visa</option>
							  <option value="discover">Discover</option>
							  <option value="mastercard">MasterCard</option>
							  <option value="maestro">Maestro</option>
							  <option value="jcb">JCB</option>
							  <option value="unionpay">China UnionPay</option>
							  <option value="amex">American Express</option>
							  <option value="dinersclubintl">Diners Club</option>
							</select>
							<label for="cc_number">Card Number</label>
							<input type="text" class="form-control" name="cc_number" id="cc_number" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" size="19">
							<label for="cc_exp_month">Expiration Month</label>
							<input type="text" class="form-control" name="cc_exp_month" id="cc_exp_month" placeholder="00">
							<label for="cc_exp_year">Expiration Year</label>
							<input type="text" class="form-control" name="cc_exp_year" id="cc_exp_year" placeholder="00">
							<label for="cc_name">Cardholder's Name</label>
							<input type="text" class="form-control" name="cc_name" id="cc_name" placeholder="John Doe">
							<label for="cc_cvc">Card Validation Code</label>
							<input type="text" class="form-control" name="cc_cvc" id="cc_cvc" placeholder="123" maxlength="3" size="3">
						  </div> -->
						  <div class="form-row">
							<label for="card-element">Credit or debit card</label>
							<div id="card-element">
							  <!-- a Stripe Element will be inserted here. -->
							</div>
							<!-- Used to display form errors -->
							<div id="card-errors"></div>
						  </div>
						  <br>
						  <div class='text-lg'>Total: $<?php echo str_replace('.00', '', $plan_detail[0]->price); ?>/mo.</div>
						  <br>
						  <input type="hidden" name="plan_amount" value="<?php echo str_replace('.00', '', $plan_detail[0]->price); ?>" />
						  <input type='submit' value='<?php echo (!empty($type) && $type=='trial') ? 'Start Free Trial' : 'Pay Now'; ?>' class='btn'>
					</form>
				</div>
				<div class='col-12 col-sm-6'>
					<table class="table table-striped" width="100%">
						<thead>
							<tr><th>What's Included with this Plan</th><td></td></tr>
						</thead>
						<tbody>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Featured Profile</b><div>(Your profile will be highlighted in local search results)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>About (Me/Us)</b><div>(Tell customers who you are in your own words)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Add a Phone Number</b><div>(Gain a business advantage by including a direct phone number)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Include Multiple Photos</b><div>(Free profiles are allowed only a single image)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Website Links</b><div>(Lead customers to your personal/business website)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>							
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Include Rates/Fees</b><div>(Adjust and display current rates for your services)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr style="display :<?php echo ($plan_detail[0]->id == 2) ? 'none' : ''; ?>"><td><b>Hours of Operations</b><div>(Let customers know when you're available)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr><td><b>Email Contact Form</b><div>(Receive email messages directly from potential clients)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr><td><b>Search Results Inclusion</b><div>(Your profile will be included in local search results on our website)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>
							<tr><td><b>Edit Profile Anywhere, Anytime</b><div>(Login on our website to easily update your profile)</div></td><td class="text-center"><i class="fa fa-check"></i></td></tr>	
						</tbody>
					</table>						
				</div>
			</div>
			  <br><div class='text-sm'><i>You will be billed monthly. Cancel anytime by going to the billing page.</i></div>
		</div>
		</div>
<div class="loader"></div>
<script>
$(function(){
  $('#card-form').submit(function() {
    $('.loader').show(); 
    return true;
  });
});
</script>		
<?= $this->endSection() ?>
<style>
.StripeElement {
    background-color: white;
    padding: 8px 12px;
    border-radius: 4px;
    border: 1px solid transparent;
    box-shadow: 0 1px 3px 0 #e6ebf1;
    -webkit-transition: box-shadow 150ms ease;
    transition: box-shadow 150ms ease;
}
.StripeElement--focus {
    box-shadow: 0 1px 3px 0 #cfd7df;
}
.StripeElement--invalid {
    border-color: #fa755a;
}
.StripeElement--webkit-autofill {
    background-color: #fefde5 !important;
}
</style>
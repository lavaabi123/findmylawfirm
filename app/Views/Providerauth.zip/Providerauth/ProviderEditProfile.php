<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

    <div class="plan bg-gray pt-2 pb-4 pb-xl-5">
        <?php echo $this->include('Common/_messages') ?>
		<div class="titleSec text-center mb-3 mb-xl-4">
			<h3 class="title-lg text-black mb-0 mb-sm-5"><?php echo $title; ?></h3>
		</div>
		<div class="container">
			<div class="row">
			<div class="leftsidecontent col-12 col-sm-4 col-lg-3">
				<?php echo $this->include('Common/_sidemenu') ?>
			</div>
			<div class="col-12 col-sm-8 col-lg-9">
			<form id="edit-form" method="post" action="<?php echo base_url(); ?>/providerauth/edit-profile-post">
			<?php echo csrf_field() ?>
				<input type="hidden" name="id" value="<?php echo $user_detail->id ?>">
				<input type="hidden" name="email" value="<?php echo $user_detail->email ?>">
				<fieldset class="form-input">				
					<h4 class="title-sm dblue mt-0 border-bottom">Basic Info</h4>
					<div class="form-section row row-cols-1 row-cols-md-3">
						<div class="form-group">
							<select name="category_id" onchange="change_categories_skills(this,'<?php echo $user_detail->id ?>')" class="form-control required">
								<option value=""><?php echo trans('Select Your Title') ?></option>
								<?php
								if(!empty($categories)){
									foreach($categories as $category){ ?>
										<option value="<?php echo $category->id; ?>" <?php echo ($user_detail->category_id == $category->id) ? 'selected':''; ?>><?php echo $category->name; ?></option>
								<?php }
								}
								?>
							</select>
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="business_name" name="business_name" placeholder="<?php echo trans('Business Name(if applicable)') ?>" value="<?php echo $user_detail->business_name ?>">
						</div>
						<div class="form-group">
							<select name='location_id' class='location required'>
								<option value='<?php echo $user_detail->location_id ?>'><?php echo $user_detail->city.', '.$user_detail->state_code.' '.$user_detail->zipcode ?></option>
							</select>
						
							<!--<select name="location_id" style="width:100%;" class="form-control js-data-example-ajax required">
							<option value="<?php echo $user_detail->location_id ?>"><?php echo $user_detail->city.', '.$user_detail->state_code.' '.$user_detail->zipcode ?></option>
							</select>-->
						</div>
						<div class="form-group">
							<input class="form-control required" type="text" id="mobile_no" name="mobile_no" placeholder="<?php echo trans('Telephone Number') ?>" value="<?php echo $user_detail->mobile_no ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="referredby" name="referredby" placeholder="<?php echo trans('Referred By') ?>" value="<?php echo $user_detail->referredby ?>">
						</div>
						<input type="hidden" name="gender" value="Male" />
						<!--<div class="form-group">
                                <select name="gender" class="form-control required">
                                    <option><?php echo trans('Gender') ?></option>
                                    <option value="Male" <?php echo ($user_detail->gender == 'Male') ? 'selected':''; ?>>Male</option>
                                    <option value="Female" <?php echo ($user_detail->gender == 'Female') ? 'selected':''; ?>>Female</option>
                                </select>
						</div>-->
						<input type="hidden" name="licensenumber" value="123" />
						<!--<div class="form-group">
							<input class="form-control" type="text" id="licensenumber" name="licensenumber" placeholder="<?php echo trans('License #') ?>" value="<?php echo $user_detail->licensenumber ?>">
						</div> -->
						<div class="form-group">
							<input class="form-control required" type="text" id="experience" name="experience" placeholder="<?php echo trans('Years of Experience') ?>" value="<?php echo $user_detail->experience ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="website" name="website" placeholder="<?php echo trans('Website') ?>" value="<?php echo $user_detail->website ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="yelp_name" name="yelp_name" placeholder="<?php echo trans('Yelp Business Name') ?>" value="<?php echo $user_detail->yelp_name ?>">
						</div>						
						<div class="form-group">
							<img src="<?php echo base_url('assets/frontend/images/yelp.png'); ?>" width="100%" />
						</div>
						
						</div>
						<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('Social Profile') ?>:</h4>
						<div class="form-section row row-cols-1 row-cols-md-3">
						<div class="form-group">
							<input class="form-control" type="text" id="facebook_link" name="facebook_link" placeholder="<?php echo trans('Facebook Link') ?>" value="<?php echo $user_detail->facebook_link ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="insta_link" name="insta_link" placeholder="<?php echo trans('Instagram Link') ?>" value="<?php echo $user_detail->insta_link ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" id="twitter_link" name="twitter_link" placeholder="<?php echo trans('Twitter Link') ?>" value="<?php echo $user_detail->twitter_link ?>">
						</div>
						</div>
						<div class="form-section">
						<div class="load_category_offering">
						<?php
						if(!empty($offering)){ ?>
						<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('Services') ?>:</h4>
						<div class="form-group row row-cols-1 row-cols-md-3 row-cols-xl-4">
						<?php
							foreach($offering as $offer){ ?>
								<label><input type="checkbox" <?php echo (!empty($user_detail->offering) && is_array(json_decode($user_detail->offering,true)) && in_array($offer->id, json_decode($user_detail->offering,true))) ? 'checked':''; ?> name="offering[]" value="<?php echo $offer->id; ?>"><?php echo $offer->name; ?></label>
						<?php }
						?>
						</div>
						<?php }
						?>
						</div>
						<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('Type of Business') ?>:</h4>
						<div class="form-section row row-cols-1 row-cols-md-3">
						<div class="form-group">
						<select class="form-control required" name="clientele[]" onchange="getComboA(this)">
								<option value="">Select</option>
						<?php
						if(!empty($client_types)){
							foreach($client_types as $clientele){ ?>
								<option value="<?php echo $clientele->id; ?>" <?php echo (!empty($user_detail->clientele) && is_array(json_decode($user_detail->clientele,true)) && in_array($clientele->id, json_decode($user_detail->clientele,true))) ? 'selected':''; ?>><?php echo $clientele->name; ?></option>
								<!--<label><input type="radio" <?php echo (!empty($user_detail->clientele) && is_array(json_decode($user_detail->clientele,true)) && in_array($clientele->id, json_decode($user_detail->clientele,true))) ? 'checked':''; ?> name="clientele[]" value="<?php echo $clientele->id; ?>"><?php echo $clientele->name; ?></label>-->
						<?php }
						}
						?>
						</select>
						</div>
						<div class="form-group">
							<input class="form-control <?php echo (!empty($user_detail->clientele) && is_array(json_decode($user_detail->clientele,true)) && in_array(2, json_decode($user_detail->clientele,true))) ? '' : 'required'; ?>" type="text" id="address" name="address" placeholder="<?php echo trans('Address') ?>" value="<?php echo $user_detail->address ?>" style="display:<?php echo (!empty($user_detail->clientele) && is_array(json_decode($user_detail->clientele,true)) && in_array(2, json_decode($user_detail->clientele,true))) ? 'none' : ''; ?>">
						</div>
						<div class="form-group">
							<input class="form-control" type="text"  id="load_location_field" readOnly disabled value="<?php echo $user_detail->city.', '.$user_detail->state_code.' '.$user_detail->zipcode ?>" style="display:<?php echo (!empty($user_detail->clientele) && is_array(json_decode($user_detail->clientele,true)) && in_array(2, json_decode($user_detail->clientele,true))) ? 'none' : ''; ?>">
						</div>
						</div>
						<div class="load_categories_skills">
							<?php 						
							if(!empty($categories_skills)){ ?>
							<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo $user_detail->skill_name ?>:</h4>
							<div class="form-group row row-cols-1 row-cols-md-3 row-cols-xl-4 mb-3 mb-lg-5">
							<?php foreach($categories_skills as $row){ ?>
								<label><input type="checkbox" <?php echo (!empty($user_detail->categories_skills) && $user_detail->categories_skills != 'null' && is_array(json_decode($user_detail->categories_skills,true)) && in_array($row->id, json_decode($user_detail->categories_skills,true))) ? 'checked':''; ?> name="categories_skills[]" value="<?php echo $row->id; ?>"><?php echo $row->name; ?></label>
							<?php } ?>
							</div>
							<?php } ?>
						</div>
						<?php if($user_detail->plan_id == 3){ ?>
							<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('Rates') ?>:</h4>
							<div class="form-group mb-3 mb-lg-5">
							<div class='panel rates text-center'>
								<?php 
								$durations = array('m'=>'Minute '.$user_detail->rate_type, 'h'=>'Hour '.$user_detail->rate_type);
								if(!empty($rate_details)){
									foreach($rate_details as $row){
									echo "<div class='d-flex rate gap-2 gap-sm-4'>
												<div class='col'>
													<input type='number' class='form-control' name='price[]' data-a-sign='$' data-v-max='99999999' data-v-min='0' data-m-dec='2' placeholder='59.99 per' value='".$row->price."'>
												</div>
												<div class='col'>
													<input type='text' class='onlyNum form-control' placerholder='60' value='".$row->duration_amount."' name='duration_amount[]'>
												</div>
												<div class='col'>
													<select name='duration[]' class='form-control'>";
													foreach($durations as $k=>$v){
														echo "<option value='$k'";
														if($k == $row->duration){
															echo " selected='selected'";
														}
														echo ">$v</option>";
													}
												echo "</select>
												</div>
												<a href='#' class='button tiny alert removeRate p-2'><i class='fa fa-trash-o'></i></a>
										</div>";
									}
								} ?>
								<a href='#' class='addRate btn yellowbtn mb-3' data-rate-type='<?php echo $user_detail->rate_type; ?>'>Add Rate</a>
								<div class='text-sm'>Rates will automatically be ordered by price, ascending</div>
							</div>
							</div>
							<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('About Me/Us') ?>:</h4>
							<div class="form-group mb-3 mb-lg-5">
							<script src="<?php echo base_url('assets/ckeditor/build/ckeditor.js'); ?>"></script>
                                <textarea class="form-control text-area" name="about_me" id="editor" placeholder="<?php echo trans('content'); ?>" required><?php echo html_escape($user_detail->about_me); ?></textarea>

								<script>                        
									ClassicEditor
										.create(document.querySelector('#editor'), {
											// CKEditor 5 configuration options
											removePlugins: [ 'MediaEmbed' ],
											simpleUpload: {
												uploadUrl: "<?php echo base_url('fileupload.php?uploadpath=userimages/'.session()->get('vr_sess_user_id').'&CKEditorFuncNum=') ?>"
											},
										})
										.then(editor => {
											console.log('CKEditor 5 initialized:', editor);
										})
										.catch(error => {
											console.error('Error initializing CKEditor 5:', error);
										});
								</script>
							</div>
							<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('Hours of Operation') ?>:</h4>
							<div class="form-group mb-3 mb-lg-5">
							<?php 
							$hoo = array();
							//print_r($hours_of_operation);exit;
							if(!empty($hours_of_operation)){
								foreach($hours_of_operation as $row){
									$hoo[$row['weekday']] = $row;	
								}
							}
							
							for($i = 1; $i <= 7; $i++){
								$last_sunday = strtotime('last Sunday');
								$cur = date('l', strtotime('+'.$i.' day', $last_sunday));
								$opat = (!empty($hoo[$i]['opens_at']) && empty($hoo[$i]['closed_all_day'])) ? date('g:ia', strtotime($hoo[$i]['opens_at'])) : '';
								$clat = (!empty($hoo[$i]['closes_at']) && empty($hoo[$i]['closed_all_day'])) ? date('g:ia', strtotime($hoo[$i]['closes_at'])) : '';
								$disp = "";
								if(!empty($hoo[$i]['closed_all_day'])){
									$disp = "none";
								}
								$start = "12:00 am";
								$end = "11:30 pm";
								$tStart = strtotime($start);
								$tEnd = strtotime($end);
								$tNow = $tStart;
								
								echo "
								<div class='hoo row align-items-center my-3'>
									<div class='thick col-12 col-sm-2'>".$cur."</div>
									<div class='panel col-12 col-sm-7 py-2 py-sm-0'>
										<div class='row align-items-center'>
											<div class='col'>";
											echo '<select class="form-control" name="hoo_'.$i.'_o"><option value="">Select</option>';
											while($tNow <= $tEnd){
												$selected = (date("g:ia",$tNow) == $opat)? 'selected' : '';
												echo '<option '.$selected.' value="'.date("g:ia",$tNow).'">'.date("g:ia",$tNow).'</option>';
												$tNow = strtotime('+30 minutes',$tNow);
											}
											echo "</select>
											</div>";
											$start = "12:00 am";
											$end = "11:30 pm";
											$tStart = strtotime($start);
											$tEnd = strtotime($end);
											$tNow = $tStart;
											echo "<div class='col'>";
											echo '<select class="form-control" name="hoo_'.$i.'_c"><option value="">Select</option>';
											while($tNow <= $tEnd){
												$selected = (date("g:ia",$tNow) == $clat)? 'selected' : '';
												echo '<option '.$selected.' value="'.date("g:ia",$tNow).'">'.date("g:ia",$tNow).'</option>';
												$tNow = strtotime('+30 minutes',$tNow);
											}
											echo "</select>
											</div>
										</div>
									</div>
									<div class='col-12 col-sm-3'>
										<label class='mb-0'><input type='checkbox' class='allDay noMarg' ";
										if(!empty($hoo[$i]['closed_all_day'])){
											echo " checked='checked'";
										}
										echo " name='hoo_".$i."_a'> Unavailable </label>
									</div>
								</div>";
							} ?>
							</div>
						<?php }	?>
						
						
						<h4 class="title-sm dblue mt-3 mt-lg-5 border-bottom"><?php echo trans('A Little About Me') ?>:</h4>
						<div class="form-section row row-cols-1 row-cols-md-2">
						<div class="form-group">
							<label>Why Did I Become A Dog Groomer?</label>
							<textarea class="form-control required" name="question1"><?php echo $user_detail->question1; ?></textarea>
						</div>
						<div class="form-group">							
								<label>What Kind Of Pets Do I Have And What Are Their Names?</label>
								<textarea class="form-control required" name="question2"><?php echo $user_detail->question2; ?></textarea>
						</div>
						</div>
						
						<input type="submit" class="btn yellowbtn fs-5 mt-5" value="Save my Profile" />
					</div>
				</fieldset>
			</form>
			</div>
			</div>
		</div>
	</div>
<script>
	$(document).ready(function() {
		toggleAllDay();
		attachLocation();
		attachTime();
	});			
	function toggleAllDay(){
		$('.allDay').each(function(){
			var thisCheck = $(this);
			var row = thisCheck.parents('.hoo').find('.row');
			if(thisCheck.is(":checked")){
				row.hide();
			}else{
				row.show();
			}
		});
	}
	$('body').on('click', '.allDay', function(){
		toggleAllDay();
	});	
	function attachLocation(){
		$('select.location').selectize({
			valueField: 'id',
			labelField: 'location',
			searchField: 'location',
			preload: true,
			create: false,
			render: {
				option: function(item, escape) {
					return '<div>'+escape(item.location)+'</div>';
				}
			},
			load: function(query, callback) {
				$.ajax({
					url: '<?php echo base_url(); ?>/providerauth/get-locations?q=' + encodeURIComponent(query),
					type: 'GET',
					error: function() {
						callback();
					},
					success: function(res) {
						res = $.parseJSON(res);
						callback(res.locations);
					}
				});
			}
		});
	}
	/* Tick picker */
	function attachTime(){
		$('.time').each(function(){
			var thisInput = $(this), min = false, max = false, interval = 5;
			if(thisInput.hasClass('past')){
				max = true
			}else if(thisInput.hasClass('future')){
				min = true
			}
			if(typeof thisInput.data('interval')){
				interval = thisInput.data('interval');
			}
			thisInput.pickatime({
				format: 'h:i a',
				formatSubmit: 'HH:i',
				interval: interval,
				hiddenName: true,
				readOnly: true,
				min: min,
				max: max
			});
		});
	}
	function change_categories_skills(_this,user_id){
		$(".load_categories_skills").html('');
		$(".load_category_offering").html('');
		var category_id = $(_this).val()
		$.ajax({
			type: "POST",
			url: '<?php echo base_url(); ?>/providerauth/get-categories-skills',
			data:{csrf_token:'1e78598ff0fc7c5d22b2b579edcdc3db',category_id:category_id,user_id:user_id},   
			dataType: 'HTML',			
			success: function (data) {	
				$(".load_categories_skills").html(data);       
			}
		});	
		$.ajax({
			type: "POST",
			url: '<?php echo base_url(); ?>/providerauth/get-category-offering',
			data:{csrf_token:'1e78598ff0fc7c5d22b2b579edcdc3db',category_id:category_id,user_id:user_id},   
			dataType: 'HTML',			
			success: function (data) {  	
				$(".load_category_offering").html(data);       
			}
		});		
	}
	function getComboA(selectObject) {
	  var value = $(selectObject).val(); 
		if(value == 2){
			$('#address').removeClass('required');
			$('#address').val('');
			$('#address').hide();
			$('#load_location_field').hide();
		}else{
			$('#address').addClass('required');
			$('#address').val('');
			$('#address').show();
			$('#load_location_field').show();
		}
	}
</script>
<?= $this->endSection() ?>
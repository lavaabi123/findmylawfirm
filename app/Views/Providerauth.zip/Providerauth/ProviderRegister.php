<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
    <div class="front-login-box">
        <!-- /.login-logo -->

                <?php echo $this->include('Common/_messages') ;
				?>
               
<div class="wizard-main">
    <div class="container-fluid">
        <div class="row align-items-start">
            <div class="col-md-5 banner-sec">
                <img class="img-fluid" id="slide1" src="<?php echo base_url(); ?>/assets/frontend/images/slider-01.jpg" alt="First slide">
				<img class="img-fluid" id="slide2" src="<?php echo base_url(); ?>/assets/frontend/images/slider-02.jpg" alt="Second slide" style="display: none;">
				<img class="img-fluid" id="slide3" src="<?php echo base_url(); ?>/assets/frontend/images/slider-03.jpg" alt="Third slide" style="display: none;">
            </div>
            <div class="col-md-7 login-sec">
                <div class="login-sec-bg">
                    <form id="example-advanced-form" method="post" action="<?php echo base_url(); ?>/providerauth/register-post" style="display: none;">
					<?php echo csrf_field() ?>
					<input type="hidden" id="fullname" name="fullname" value="">
                        <h3></h3>
                        <fieldset class="form-input">
						<div class="titleSec">
							<h3 class="title-xl black mb-0"><?php echo trans('Sign Up as a Groomer') ?></h3>
							<p class="text-grey fs-6"><?php echo trans('Get started for FREE with no obligation') ?></p>
						</div>
							<div class="form-section">
								<div class="form-group">
									<input class="form-control required" type="text" id="first_name" name="first_name" placeholder="<?php echo trans('form_firstname') ?>" value="<?php echo old('first_name') ?>">
								</div>
								<div class="form-group">
									<input class="form-control required" type="text" id="last_name" name="last_name" placeholder="<?php echo trans('form_lastname') ?>" value="<?php echo old('last_name') ?>">
									<input type="hidden" id="role" name="role" value="2">
								</div>
								<div class="form-group">
									<input class="form-control required email" type="email" id="email" name="email" placeholder="<?php echo trans('form_email') ?>" value="<?php echo old('email') ?>">
								</div>
								<div class="form-group">
									<input class="form-control required" type="password" id="password" name="password" placeholder="<?php echo trans('form_password') ?>">
								</div>
								<div class="form-group">
									<input type="password" name="confirm_password" class="form-control required" placeholder="<?php echo trans("form_confirm_password"); ?>" data-parsley-equalto="#password">
								</div>
							</div>
                        </fieldset>

                        <h3></h3>
                        <fieldset class="form-input">
						<div class="titleSec">
                            <h3 class="title-xl black mb-0"><?php echo trans('Provide Additional Information') ?></h3>
                            <p class="text-grey fs-6"><?php echo trans('This way you can serve better!') ?></p>
							</div>
							<div class="form-section">
                            <div class="form-group">
                                <select name="category_id" onchange="change_category_offering(this)"  class="form-control required" required>
                                    <option value=""><?php echo trans('Select Your Title') ?></option>
									<?php
									if(!empty($categories)){
										foreach($categories as $category){ ?>
											<option value="<?php echo $category->id; ?>" <?php echo (old('category_id') == $category->id) ? 'selected':''; ?>><?php echo $category->name; ?></option>
									<?php }
									}
									?>
                                </select>
                            </div>
                            <div class="form-group">							
								<select name='location_id' id="select_location_id" class='form-control location required'>
									<option value='<?php echo old('location_id') ?>'>Choose Your Location</option>
								</select>
								<!--<select name="location_id" style="width:100%;" class="form-control js-data-example-ajax required"></select>-->
                            </div>
							
                            <div class="form-group">
                                <input class="form-control required" type="text" id="mobile_no" name="mobile_no" placeholder="<?php echo trans('Telephone Number') ?>" value="<?php echo old('mobile_no') ?>">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="text" id="referredby" name="referredby" placeholder="<?php echo trans('Referred By') ?>" value="<?php echo old('referredby') ?>">
                            </div>
                            </div>
                        </fieldset>

                        <h3></h3>
                        <fieldset class="form-input">
						<div class="titleSec">
                            <h3 class="title-xl black mb-0"><?php echo trans('Please finalize the details!') ?></h3>
                            <p class="text-grey fs-6"><?php echo trans('This way we get you the right customers.') ?></p>
							</div>
							<div class="form-section">
							<input type="hidden" name="gender" value="Male" />
                            <!--<div class="form-group">
                                <select name="gender" class="form-control required">
                                    <option><?php echo trans('Gender') ?></option>
                                    <option value="Male" <?php echo (old('gender') == 'Male') ? 'selected':''; ?>>Male</option>
                                    <option value="Female" <?php echo (old('gender') == 'Female') ? 'selected':''; ?>>Female</option>
                                </select>
                            </div>-->
                            <h4 class="title-md black mt-3 mt-lg-5"><?php echo trans('Type of Business') ?>:</h4>
                            <div class="form-group">
								<select class="form-control required" name="clientele[]" onchange="getComboA(this)">
								<option value="">Select</option>
								<?php
								if(!empty($client_types)){
									foreach($client_types as $clientele){ ?>
										<option value="<?php echo $clientele->id; ?>"><?php echo $clientele->name; ?></option>
										<!--<label><input type="radio" <?php echo (is_array(old('clientele')) && in_array($clientele->id, old('clientele'))) ? 'checked':''; ?> name="clientele[]" value="<?php echo $clientele->id; ?>"><?php echo $clientele->name; ?></label>-->
								<?php }
								}
								?>
								</select>
                            </div>							
                            <div class="form-group">
                                <input class="form-control" type="text" id="business_name" name="business_name" placeholder="<?php echo trans('Business Name(if applicable)') ?>" value="<?php echo old('business_name') ?>">
                            </div>
													
                            <div class="form-group">
                                <input class="form-control required" type="text" id="address" name="address" placeholder="<?php echo trans('Address') ?>" value="<?php echo old('address') ?>" >
                            </div>
							
							<div class="form-group">
								<input type="text" class="form-control" value="" id="load_location_field" readonly disabled />
							</div>
							
							<input type="hidden" name="licensenumber" value="123" />
                            <!--<div class="form-group">
                                <input class="form-control" type="text" id="licensenumber" name="licensenumber" placeholder="<?php echo trans('License #') ?>" value="<?php echo old('licensenumber') ?>">
                            </div>-->
							
                            <div class="form-group">
                                <input class="form-control required" type="text" id="experience" name="experience" placeholder="<?php echo trans('Years of Experience') ?>" value="<?php echo old('experience') ?>">
                            </div>
							<div class="load_category_offering">
							<?php
							$offeringyes = 0;
							if(!empty($offering)){
								foreach($offering as $offer){ 
								if((!empty(old('category_id')) && old('category_id') == $offer->category_id ) || (empty(old('category_id')))){
									$offeringyes = 1;
								} }
							}
							?>
							<?php if($offeringyes == 1){ ?>
                            <h4 class="title-md black mt-3 mt-lg-5"><?php echo trans('Services') ?>:</h4>
                            <div class="form-group">
							<?php
							$offeringyes = 0;
							if(!empty($offering)){
								foreach($offering as $offer){ 
								if((!empty(old('category_id')) && old('category_id') == $offer->category_id ) || (empty(old('category_id')))){
									$offeringyes = 1;
								?>
									<label><input type="checkbox" <?php echo (is_array(old('offering')) && in_array($offer->id, old('offering'))) ? 'checked':''; ?> name="offering[]" value="<?php echo $offer->id; ?>"><?php echo $offer->name; ?></label>
								<?php } }
							}
							?>
                            </div>
							<?php } ?>						
							
							</div>							
							
							<h4 class="title-md black mt-3 mt-lg-5">Specializing In:</h4>
							<?php 						
							if(!empty($categories_skills)){ ?>
							<div class="form-group mb-5">
							<?php foreach($categories_skills as $row){ ?>
								<label><input type="checkbox" name="categories_skills[]" value="<?php echo $row->id; ?>"><?php echo $row->name; ?></label>
							<?php } ?>
							</div>
							<?php } ?>
							
							<h4 class="title-md black mt-3 mt-lg-5">A Little About Me <i class="toolTipinfo" data-toggle="popover">i</i></h4>
							<div class="form-group mb-5">
								<label>Why Did I Become A Dog Groomer?</label>
								<textarea class="form-control required" name="question1"></textarea>
								<label>What Kind Of Pets Do I Have And What Are Their Names?</label>
								<textarea class="form-control required" name="question2"></textarea>
                            </div>
							
                            </div>
                        </fieldset>
                    </form>         
                </div>
            </div>          
        </div>
    </div>
</div>


            
    </div>
    <!-- /.login-box -->
<script>
	$(document).ready(function() {
		attachLocation();
		
		var simg = '<?php echo base_url().'/assets/img/favicon.png'; ?>';
		$('[data-toggle="popover"]').popover({
			placement : 'right',
			trigger : 'hover',
			html : true,
			content : '<div class="tooltip-inner text-start"><p class="dblue mb-2 d-flex align-items-center gap-1 fw-bold fs-8"><img width="24" src="'+simg+'"> A little extra about your groomer!</p><p class="mb-0">These are 2 mandatory questions for your groomer to answer when creating a profile.</p><p>This givens you a little more insight into who you choose to groom your furry baby!</p></div>'
		});
	
	});	

const getLinkTitle = (id) => {
  let title;
  if (id) {
    const selectedLink = _.find(selectLinks, (link) => {
      return link.id === parseInt(id);
    });
    if (selectedLink) {
      title = selectedLink.title;
    }
  }
  return title;
};
	
	function attachLocation(){
		$('select.location').selectize({
			valueField: 'id',
			labelField: 'location',
			searchField: 'location',
			create: false,
			preload: true,
			render: {
				option: function(item, escape) {
					return '<div>'+escape(item.location)+'</div>';
				}
			},
			load: function(query, callback) {
				
				$.ajax({
					url: '<?php echo base_url(); ?>/providerauth/get-locations?q=' + encodeURIComponent(query),
					type: 'GET',
					error: function() {
						callback();
					},
					success: function(res) {
						res = $.parseJSON(res);
						callback(res.locations);
					}
				});
			},onChange:function(value){
				$("#load_location_field").val(this.getItem(value)[0].innerHTML);
			}
		});
	}
	
	function change_category_offering(_this){
		$(".load_category_offering").html('');
		var category_id = $(_this).val()
		$.ajax({
			type: "POST",
			url: '<?php echo base_url(); ?>/providerauth/get-category-offering',
			data:{csrf_token:'1e78598ff0fc7c5d22b2b579edcdc3db',category_id:category_id,from:'register'},   
			dataType: 'HTML',			
			success: function (data) {  	
				$(".load_category_offering").html(data);       
			}
		});		
	}
	
	function getComboA(selectObject) {
	  var value = $(selectObject).val(); 
		if(value == 2){
			$('#address').removeClass('required');
			$('#address').val('');
			$('#address').hide();
			$('#load_location_field').hide();
		}else{
			$('#address').addClass('required');
			$('#address').val('');
			$('#address').show();
			$('#load_location_field').show();
		}
	}
</script>
<?= $this->endSection() ?>
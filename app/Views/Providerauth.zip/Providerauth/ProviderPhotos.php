<?= $this->section('content') ?>
    <div class="proPhotos bg-gray pt-2 pb-4 pb-xl-5">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/admin/plugins/bootstrap-4-tag-input/tagsinput.css">
	<style>
	.bootstrap-tagsinput .badge {
		color: #797979;
	}
	</style>
	<?= $this->extend('layouts/main') ?>
        <?php echo $this->include('Common/_messages') ?>
		<div class="titleSec text-center mb-3 mb-xl-4">
			<h3 class="title-lg text-black mb-0 mb-sm-5">My <?php echo $title; ?></h3>
		</div>
		<div class="container">
			<div class="row">
				<div class="leftsidecontent col-12 col-sm-4 col-lg-3">
				<?php echo $this->include('Common/_sidemenu') ?>
				</div>
				<div class="col-12 col-sm-8 col-lg-9">
					<div class='row'>
						<div class='col-12 <?php if(!empty($user_photos)){ ?>col-sm-6<?php }else{ ?>col-sm-6<?php } ?>'>
							<h3 class="title-sm dblue border-bottom">Add Photo</h3>
							<form action='<?php echo base_url(); ?>/providerauth/photos' class='panel mb-4' id="photoupload" method='post' enctype='multipart/form-data'>
								<input type="text" data-role="tagsinput" class="form-control mb-2" value="" id="image_tag" name="image_tag" placeholder="Enter Tag" class="image_tag" />
								<div class="d-flex justify-content-space align-items-center mt-3">
									<input type='file' id="userphoto" name='upload'>
									<input type='button' value='Upload' class='btn photoupload'>
								</div>
								<p class="upload-loading" style="display:none">Uploading...</p>
								<p class="upload-loading-success text-success" style="display:none"></p>
								<p class="upload-loading-error text-danger" style="display:none"></p>
							</form>
						</div>
					
						<div class='col-12 <?php if(!empty($user_photos)){ ?>col-sm-6<?php }else{ ?>col-sm-6<?php } ?>'>
							<h3 class="title-sm dblue border-bottom">Current Photo<?php if(!empty($user_photos)){ echo 's'; } ?></h3>
							<div class='load-images'>
								<?php if(!empty($user_photos)){ ?>
								<?php if(count($user_photos) > 1){ ?>
								<p>(<?php echo trans('Drag and drop to organize your photos'); ?>)</p>
								<?php } ?>
								<ul class="row" id="imageListId">
								<?php
									foreach($user_photos as $row){
										echo "<li class='col-6 col-md-3 listitemClass d-flex' id='imageNo".$row['id']."'><div class='pic'><img width='100%' height='150px' src='".base_url()."/uploads/userimages/".session()->get('vr_sess_user_id')."/".$row['file_name']."'></div><div class='trash' onclick='deletephotos(".$row['id'].")' data-id='".$row['id']."' style='cursor:pointer'><i class='fa fa-trash-o'></i></div></li>";
									}
								?>
								</ul>
								<?php 
								}else{
									echo 'please upload.';
								} ?>
							</div>
						</div>
						<!--<a href='<?php echo base_url(); ?>/providerauth/dashboard' class='btn mt-5 w-auto m-auto'>I'm Done, Go to my Dashboard</a>-->
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
	$(document).ready(function(){
		$(".photoupload").on("click", function(){
			$.ajax({
				url: '<?php echo base_url(); ?>/providerauth/photos_post',
				data: {check:'1'},
				type: 'POST',
				dataType: 'JSON',
				success: function(response){
					if(response == '2'){
						$(".upload-loading-error").html('Please Upgrade your plan to upload more photos.');
						$(".upload-loading-error").show().delay(5000).fadeOut();
					}else if($("#image_tag").val() == ''){
						$(".upload-loading-error").html('Please add tags to your photo.');
						$(".upload-loading-error").show().delay(5000).fadeOut();
					}else{
						var dataf = new FormData($("#photoupload")[0]);
						$.ajax({
							url: '<?php echo base_url(); ?>/fileupload.php?uploadpath=userimages/'+'<?php echo session()->get('vr_sess_user_id'); ?>',
							data: dataf,
							type: 'POST',
							dataType: 'JSON',
							processData: false,
							contentType: false,
							cache: false,
							enctype: 'multipart/form-data',
							beforeSend: function(){
								$('.upload-loading').show();
							},
							success: function(response){
								$('.upload-loading').hide();
								if(response.uploaded == 1){
									$("#userphoto").val(null);
									$.ajax({
										url: '<?php echo base_url(); ?>/providerauth/photos_post',
										data: {check:'2',image:response.fileName,image_tag:$("#image_tag").val()},
										type: 'POST',
										dataType: 'HTML',
										success: function(response){
											if(response != ''){
												$(".load-images").html(response);
											}
											$("#imageListId").sortable({
												update: function(event, ui) {
														getIdsOfImages();
													} //end update	
											});											
										}
									})
									$("#image_tag").tagsinput('removeAll');
									
									$(".upload-loading-success").html('Uploaded Successfully!');
									$(".upload-loading-success").show().delay(5000).fadeOut();
								}else{
									$(".upload-loading-error").html(response.error);
									$(".upload-loading-error").show().delay(5000).fadeOut();
								}
							}
						})
					}					
				}
			})			
		});
	});
	function deletephotos(photo_id){
		$.confirm({
			title: 'Confirm Deletion',
			content: 'Are you sure you want to delete this photo?',
			buttons: {
				confirm: function () {
					$.ajax({
						url: '<?php echo base_url(); ?>/providerauth/photos_delete',
						data: {photo_id:photo_id},
						type: 'POST',
						dataType: 'HTML',
						success: function(response){
							if(response != ''){
								$(".load-images").html(response);
								$(".upload-loading-success").html('Deleted Successfully!');
								$(".upload-loading-success").show().delay(5000).fadeOut();
							}	
							$("#imageListId").sortable({
								update: function(event, ui) {
										getIdsOfImages();
									} //end update	
							});							
						}
					})
				},
				cancel: function(){
					
				}
			}
		});
	}
	$(function() {
		$("#imageListId").sortable({
			update: function(event, ui) {
					getIdsOfImages();
				} //end update	
		});
	});
	function getIdsOfImages() {
		var values = [];
		$('.listitemClass').each(function(index) {
			values.push($(this).attr("id")
						.replace("imageNo", ""));
		});
		$('#outputvalues').val(values);
		$.ajax({
			url: '<?php echo base_url(); ?>/providerauth/photos_post',
			data: {check:'3',ids:values},
			type: 'POST',
			dataType: 'HTML',
			success: function(response){		
														
			}
		})
	}
</script>
<?= $this->endSection() ?>